fun main()
{
    try{
    println("Введите стороны треугольника")
    val a= readln().toDouble()
    val b= readln().toDouble()
    val c= readln().toDouble()
    var s=0.0
    var p=0.0
    if(a<=0||b<=0||c<=0)
    {
        println("Сторона треугольника не может быть меньше или равна нулю")
    }
    else
    {
        if (a + b > c && b + c > a && a + c > b)
        {
        println("Введенные числа могут являться сторонами треугольника")
            s=(a+b+c)/2
            p=a+b+c
            println("s:%.2f:\tp:%.2f:".format(s, p))
        }
        else
        {
        println("Введенные числа не могут являться сторонами треугольника")
        }
    }
    }catch(e:Exception)
    {
        println("Некоркктные данные")
    }
}