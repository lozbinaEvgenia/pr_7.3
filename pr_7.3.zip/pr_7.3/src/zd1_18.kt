import kotlin.math.*
import kotlin.math.round
fun main()
{
    try
    {
        println("Введите сторону равностороннего треугольника")
        val a= readln().toDouble()
        if(a<=0)
        {
           println("Сторона треугольника не может быть меньше или равна нулю")
        }
        else
        {
            var r=0.0
            var R=0.0
            r=a / (2 * sqrt(3.0))
            R=a / sqrt(3.0)
            println("r:%.2f:\tR:%.2f:".format(r, R))
        }
    }
    catch(e:Exception)
    {
        println("Некорекктный ввод данных")
    }
}