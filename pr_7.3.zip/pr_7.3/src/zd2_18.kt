
fun main()
{
    try
    {
    println("Введите координаты для M1")
    val m1x = readln().toDouble()
    val m1y = readln().toDouble()
    println("Введите координаты для M2")
    val m2x = readln().toDouble()
    val m2y = readln().toDouble()
    println("Введите координаты для N1")
    val n1x = readln().toDouble()
    val n1y = readln().toDouble()
    println("Введите координаты для N2")
    val n2x = readln().toDouble()
    val n2y = readln().toDouble()

    val slope1 = (m2y - m1y) / (m2x - m1x)
    val slope2 = (n2y - n1y) / (n2x - n1x)

    if (slope1 == slope2)
    {
        println("Прямые параллельны")
    } else
    {
        val x = ((n2y - n1y) * (n1x - m1x) + (n2x - n1x) * m1y) / ((n2x - n1x) + (n2y - n1y))
        val y = m1y + (x - m1x) * (m2y - m1y) / (m2x - m1x)
        println("Прямые пересекаются в точке ($x, $y)")
    }
    }
    catch (e:Exception)
    {
        println("Ошибка")
    }
}