import kotlin.math.*
fun main()
{
    try
    {
    println("Введите a")
        val a= readln().toDouble()
        if(a<=0)
        {
            println("а не может быть меньше или равно нулю")
        }
        else
        {
            println("Введите b")
        val b= readln().toDouble()
        println("Введите c")
        val c= readln().toDouble()
            var x=0.toDouble()
            var y=0.toDouble()
            x = -b / (2*a)
            y=a*x.pow(2.0)+b*x+c
            println("x:%.2f:\ty:%.2f:".format(x, y))

        }

    }
    catch(e:Exception)
    {
        println("Ошибка")
    }

}